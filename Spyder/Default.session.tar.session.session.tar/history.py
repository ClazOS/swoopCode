runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
# *** Spyder Python Console History Log ***
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
scoreFetcher()
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
scoreFetcher()
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
scoreFetcher()
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
793+213
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraper.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraper.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/classScratch.py', wdir=r'/Users/swoop/Google Drive/Python')
rectangle
type(rectangle)
printrectangle
print rectangle
area.shape
print area.shape
print shape.area
shape
print shape
runfile('/Users/swoop/Documents/Python/classScratch.py', wdir=r'/Users/swoop/Google Drive/Python')
print shape.area
print area.shape
shape
rectangle.area
print rectangle.area
type(rectangle.area)
rectangle
print rectangle
draw rectangle
rectangle.author
rectangle.author='Claz'
rectangle.author
runfile('/Users/swoop/Dropbox/pynance/pynance/fundamentals.py', wdir=r'/Users/swoop/Google Drive/Python')
pip
import quandl
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Dropbox/pynance/pynance/fundamentals.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
range(1,3
)
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
debugfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
ds
as
ad
import requests
from lxml import html
import csv
import random
def scoreFetcher(): #returns a dict of fixtures
        page=requests.get('http://www.espnfc.com/scores')
        tree=html.fromstring(page.text)
        league=tree.xpath('//*[@id="score-leagues"]/div[1]/h4/a/text()')
        fixtures={"League":league[-1]}
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')

##---(Tue Nov  4 15:05:45 2014)---
runfile('/Users/swoop/Documents/Python/scoreScraper.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
fixtures['game1']
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
fixtures['game1'
]
fixtures['game2']
fixtures
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
fixtures['game1']
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraperWIP.py', wdir=r'/Users/swoop/Google Drive/Python')

##---(Wed Nov  5 12:18:20 2014)---
runfile('/Users/swoop/Documents/Python/yahooScraper.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('xxcaazz','xxbaaz')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('xxcaazz','xxbaaz')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('xxcaazz','xxbaaz')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('xxcaazz','xxbaaz')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('xxcaazz','xxbaaz')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('abc','abc')
runfile('/Users/swoop/Documents/Python/codingBatWarmups.py', wdir=r'/Users/swoop/Google Drive/Python')
string_match('abc','abc')
runfile('/Users/swoop/Documents/Python/scratch.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/soccerScraper.py', wdir=r'/Users/swoop/Google Drive/Python')
runfile('/Users/swoop/Documents/Python/Scrapers/sumTest.py', wdir=r'/Users/swoop/Google Drive/Python')
sumItUp(https://www.cryptocoinsnews.com/professor-analyzes-characteristics-bitcoin-users-with-google-trends/)
sumItUp('https://www.cryptocoinsnews.com/professor-analyzes-characteristics-bitcoin-users-with-google-trends/')